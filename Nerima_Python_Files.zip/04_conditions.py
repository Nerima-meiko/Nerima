age = int(input("Age: "))

if age >= 18:
    print("Adult")
else:
    print("Minor")
