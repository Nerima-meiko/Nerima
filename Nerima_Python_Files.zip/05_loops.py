for i in range(5):
    print("Loop", i)
