# Nerima Python Repo

This repo contains beginner Python exercises.

## Files

- 01_hello_world.py
- 02_variables.py
- 03_input_output.py
- 04_conditions.py
- 05_loops.py
