print("Hello, Nerima!")
