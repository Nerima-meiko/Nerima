book = "Python 101"
price = 49.9
in_stock = True

print("Book:", book)
print("Price:", price)
print("In stock:", in_stock)
